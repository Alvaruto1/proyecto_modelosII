const app = new Vue({
  el :'#app',
  data:{
    titulo :'Hola Mundo',
    contenido :' ',
    color : true,
    juegos:[
      {titulo: 'MortalCombat', edad:19 },
      {titulo: 'AngryBirds', edad:8 },
      {titulo: 'Asassins Creed', edad:9 }
    ],
    juego :''

  },
  methods:{
    agregarJuego () {
      this.juegos.push({
        titulo: this.juego , edad: 0
      });

    }

  },

})
