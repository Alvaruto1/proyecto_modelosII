const app = new Vue({
  el :  '#app',
  data:{
    titulo : "Estos son los juegos",
    juegos :[
      {nombre:'Juego1', cantidad:'Imagen1'},
      {nombre:'Juego2', cantidad:'Imagen2'},
      {nombre:'Juego3', cantidad:'Imagen3'},
      {nombre:'Juego4', cantidad:'Imagen4'},
      {nombre:'Juego5', cantidad:'Imagen5'}
    ]
  }

})
